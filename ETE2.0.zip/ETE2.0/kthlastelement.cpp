#include <bits/stdc++.h>
using namespace std;
int main(){
    int m;
    cin>>m;
    vector <int> x(m);
    
}