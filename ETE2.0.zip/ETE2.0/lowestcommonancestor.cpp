#include<bits/stdc++.h>
using namespace std;

int lca(vector<int>v,int x,int y){

    int xind=-1,yind=-1;

    for(int i=0;i<v.size();++i){
        if(v[i]==x) xind=i;
        if(v[i]==y) yind=i;
    }
    if(xind==-1 ||yind==-1){
        return -1;

    }
    unordered_set<int> anc;
    while(xind>=0){
        anc.insert(xind);
        if(xind==0){
            break;
        }
        xind=(xind-1)/2;
    }
    while(yind>=0){
        if(anc.count(yind)){
            return v[yind];
        }
        if(yind ==0) 
        break;
        yind=(yind-1)/2;
    }


    return -1;


}

int main(){
    string str;
    getline(cin,str);
    istringstream s(str);
    string value;
    vector<int> v;
    while(s>> value){
        if(value=="-1"){
            v.push_back(-1);
        }
        else{
            v.push_back(stoi(value));
        }
    }
    int x,y;
    cin>>x>>y;
    cout<<lca(v,x,y);
}